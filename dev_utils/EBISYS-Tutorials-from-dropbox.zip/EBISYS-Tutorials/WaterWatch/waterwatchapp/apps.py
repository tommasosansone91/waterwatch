from django.apps import AppConfig


class WaterwatchappConfig(AppConfig):
    name = 'waterwatchapp'
